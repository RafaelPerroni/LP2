﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        int A, B, C;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtA.Text, out A) || (A != 0))
            {
                MessageBox.Show("Lado A Inválido!");
                Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtA.Text, out B) || (B != 0))
                MessageBox.Show("Lado B Inválido!");
        }

        private void txtC_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(txtA.Text, out C) || (C != 0))
                MessageBox.Show("Lado C Inválido!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }
    }
}
