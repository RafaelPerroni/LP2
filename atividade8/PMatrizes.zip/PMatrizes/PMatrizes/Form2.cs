﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {

            string[] nomes = new string[10];
            int[] comprimentos = new int[10];

            for (int i = 0; i < 10; i++)
            {
                string nome;

                // Entrada e validação do nome
                do
                {
                    nome = Microsoft.VisualBasic.Interaction.InputBox(
                        $"Digite o nome completo da pessoa {i + 1}:",
                        "Entrada de Nomes"
                    ).Trim();

                    if (string.IsNullOrWhiteSpace(nome))
                    {
                        MessageBox.Show("O nome não pode ser vazio ou apenas espaços!", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        break;
                    }

                } while (true);

                nomes[i] = nome;

                // Remove todos os espaços e conta os caracteres restantes
                string nomeSemEspacos = nome.Replace(" ", "");
                comprimentos[i] = nomeSemEspacos.Length;
            }

            // Exibe no ListBox
            listBox1.Items.Clear();
            listBox1.Items.Add("Nome - Tamanho (sem espaços)");
            listBox1.Items.Add("====================================");

            for (int i = 0; i < 10; i++)
            {
                listBox1.Items.Add($"{nomes[i]} - {comprimentos[i]} caracteres");
            }
        }

        private void listBoxNomes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
