﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            string aux = "";
            
            for (int i = 0; i < 20; i++)
            {
                double media = 0;
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite sua nota {j + 1} do aluno", "Entrada de dados");
                    if (!double.TryParse(aux, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dados Inválidos");
                        i--;
                    }
                    else
                    {
                        media += Notas[i, j];

                    }
                }
                string Saida = "";
                Saida += $"Aluno: {i + 1}: Media: {media / 3}";
                MessageBox.Show(Saida);
            }
            }





        private void Exrc1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;
            for (int i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox($"Digite o n{i + 1}º numero", "Entrada de dados");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("VALOR INVÁLIDO");
                    i--;
                }
            }
            Array.Reverse(vetor);
            aux = "";
            aux = string.Join("\n", vetor);
            MessageBox.Show(aux);

        }

        private void Exr2_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() { "Ana", "Andre","Beatriz", "Carla", "Otávio","Camila", "João", "Joana", "Marcelo" , "Pedro", "Thais" };
            Lista.Remove ("Otávio");
            string aux = "";
            foreach (string nome in Lista)
            {
                aux += nome + "\n";
            }
            MessageBox.Show(aux);
        }

        private void Exr4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["Exr4"].BringToFront();
            }
            else
            {
                Exercicio4 frm4 = new Exercicio4 ();
                frm4.Show();
            }
        }

        private void Exr5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["Exr5"].BringToFront();
            }
            else
            {
                Exercicio5 frm5 = new Exercicio5();
                frm5.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();

        }
    }
}
