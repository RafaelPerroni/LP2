﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnVerf_Click(object sender, EventArgs e)
        {
            int ultimoDigitoRA = 7; // altere aqui conforme seu RA
            int N = ultimoDigitoRA == 0 ? 2 : ultimoDigitoRA + 1;
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] respostas = new char[N, 10];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resp;
                    do
                    {
                        resp = Microsoft.VisualBasic.Interaction.InputBox(
                            $"Aluno {i + 1} - Questão {j + 1} (A–E):", "Respostas").Trim().ToUpper();
                    } while (resp.Length != 1 || !"ABCDE".Contains(resp));

                    respostas[i, j] = resp[0];
                }
            }

            listBoxGab.Items.Add("Gabarito: " + string.Join(" ", gabarito));
            for (int i = 0; i < N; i++)
            {
                int acertos = 0;
                string linha = "";
                for (int j = 0; j < 10; j++)
                {
                    linha += respostas[i, j] + " ";
                    if (respostas[i, j] == gabarito[j]) acertos++;
                }
                listBoxGab.Items.Add($"Aluno {i + 1}: {linha}| Acertos: {acertos}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
