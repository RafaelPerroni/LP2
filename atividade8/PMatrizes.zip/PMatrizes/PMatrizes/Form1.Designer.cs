﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Exrc1 = new System.Windows.Forms.Button();
            this.Exr2 = new System.Windows.Forms.Button();
            this.Exr3 = new System.Windows.Forms.Button();
            this.Exr4 = new System.Windows.Forms.Button();
            this.Exr5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Exrc1
            // 
            this.Exrc1.Location = new System.Drawing.Point(212, 89);
            this.Exrc1.Name = "Exrc1";
            this.Exrc1.Size = new System.Drawing.Size(139, 58);
            this.Exrc1.TabIndex = 0;
            this.Exrc1.Text = "Exercicio 1";
            this.Exrc1.UseVisualStyleBackColor = true;
            this.Exrc1.Click += new System.EventHandler(this.Exrc1_Click);
            // 
            // Exr2
            // 
            this.Exr2.Location = new System.Drawing.Point(444, 89);
            this.Exr2.Name = "Exr2";
            this.Exr2.Size = new System.Drawing.Size(117, 58);
            this.Exr2.TabIndex = 1;
            this.Exr2.Text = "Exercicio 2";
            this.Exr2.UseVisualStyleBackColor = true;
            this.Exr2.Click += new System.EventHandler(this.Exr2_Click);
            // 
            // Exr3
            // 
            this.Exr3.Location = new System.Drawing.Point(212, 169);
            this.Exr3.Name = "Exr3";
            this.Exr3.Size = new System.Drawing.Size(139, 54);
            this.Exr3.TabIndex = 2;
            this.Exr3.Text = "Exercicio 3";
            this.Exr3.UseVisualStyleBackColor = true;
            this.Exr3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Exr4
            // 
            this.Exr4.Location = new System.Drawing.Point(444, 169);
            this.Exr4.Name = "Exr4";
            this.Exr4.Size = new System.Drawing.Size(117, 54);
            this.Exr4.TabIndex = 3;
            this.Exr4.Text = "Exercicio 4";
            this.Exr4.UseVisualStyleBackColor = true;
            this.Exr4.Click += new System.EventHandler(this.Exr4_Click);
            // 
            // Exr5
            // 
            this.Exr5.Location = new System.Drawing.Point(338, 243);
            this.Exr5.Name = "Exr5";
            this.Exr5.Size = new System.Drawing.Size(121, 67);
            this.Exr5.TabIndex = 4;
            this.Exr5.Text = "Exercicio 5";
            this.Exr5.UseVisualStyleBackColor = true;
            this.Exr5.Click += new System.EventHandler(this.Exr5_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(609, 316);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 71);
            this.button1.TabIndex = 5;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Exr5);
            this.Controls.Add(this.Exr4);
            this.Controls.Add(this.Exr3);
            this.Controls.Add(this.Exr2);
            this.Controls.Add(this.Exrc1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Exrc1;
        private System.Windows.Forms.Button Exr2;
        private System.Windows.Forms.Button Exr3;
        private System.Windows.Forms.Button Exr4;
        private System.Windows.Forms.Button Exr5;
        private System.Windows.Forms.Button button1;
    }
}

