﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace PEstoque1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produtoMes = new int[2, 4];
            string auxiliar = "";
            int soma;
            int total = 0;
            for (int i = 0; i < 2; i++)
            {
                soma = 0;
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o número de Produtos da semana:{j + 1}", "Entrada de Dados");
                    if (!int.TryParse(auxiliar, out produtoMes[i, j]))
                    {
                        MessageBox.Show("Valor Inválido");
                        j--;
                    }
                    else if (produtoMes[i, j] >= 0)
                    {
                        lstBx.Items.Add($"Total de entrada do Produto:{i + 1} Semana:{j + 1} - {auxiliar}");
                        soma += produtoMes[i, j];
                        total += produtoMes[i, j];
                    }
                    else
                    {
                        MessageBox.Show("Valor Inválido");
                        j--;
                    }

                }
                lstBx.Items.Add($">>Total Entradas Produto{i + 1}:                       {soma}");
                lstBx.Items.Add("--------------------------------------------------------------");
            }
            lstBx.Items.Add($">>Total Geral de entradas:                         {total}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBx.Items.Clear();
        }
    }
}