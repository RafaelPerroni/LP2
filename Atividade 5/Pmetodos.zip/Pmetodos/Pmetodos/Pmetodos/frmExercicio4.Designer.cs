﻿namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNum = new System.Windows.Forms.Button();
            this.btnPosicao = new System.Windows.Forms.Button();
            this.btnContaLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(206, 45);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(372, 96);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContaNum
            // 
            this.btnContaNum.Location = new System.Drawing.Point(189, 185);
            this.btnContaNum.Name = "btnContaNum";
            this.btnContaNum.Size = new System.Drawing.Size(93, 121);
            this.btnContaNum.TabIndex = 1;
            this.btnContaNum.Text = "Conta Números";
            this.btnContaNum.UseVisualStyleBackColor = true;
            this.btnContaNum.Click += new System.EventHandler(this.btnContaNum_Click);
            // 
            // btnPosicao
            // 
            this.btnPosicao.Location = new System.Drawing.Point(340, 185);
            this.btnPosicao.Name = "btnPosicao";
            this.btnPosicao.Size = new System.Drawing.Size(88, 121);
            this.btnPosicao.TabIndex = 2;
            this.btnPosicao.Text = "Posição 1º caracter branco";
            this.btnPosicao.UseVisualStyleBackColor = true;
            this.btnPosicao.Click += new System.EventHandler(this.btnPosicao_Click);
            // 
            // btnContaLetra
            // 
            this.btnContaLetra.Location = new System.Drawing.Point(492, 185);
            this.btnContaLetra.Name = "btnContaLetra";
            this.btnContaLetra.Size = new System.Drawing.Size(86, 121);
            this.btnContaLetra.TabIndex = 3;
            this.btnContaLetra.Text = "Conta Letras";
            this.btnContaLetra.UseVisualStyleBackColor = true;
            this.btnContaLetra.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaLetra);
            this.Controls.Add(this.btnPosicao);
            this.Controls.Add(this.btnContaNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContaNum;
        private System.Windows.Forms.Button btnPosicao;
        private System.Windows.Forms.Button btnContaLetra;
    }
}